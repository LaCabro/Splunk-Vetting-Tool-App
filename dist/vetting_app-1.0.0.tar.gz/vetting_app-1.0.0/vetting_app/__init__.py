# vetting_app/__init__.py
from .VetAssist import *
